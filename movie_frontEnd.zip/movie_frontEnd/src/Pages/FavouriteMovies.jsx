import "../css/Favorites.css"
function Favourite(){
    return <div className="emptyFav">
        <h1>add some favourite movies.</h1>
    </div>


}
export default Favourite