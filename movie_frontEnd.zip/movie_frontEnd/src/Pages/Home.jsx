import Moviecard from "../Components/movieCard"
import "../CSS/Home.css"
import { useEffect, useState } from "react"
import { searchMovies, getPopularMovies } from "../services/api"

//SPECIAL NOTE THE CSS FILES ARE NOT MINE 
//I HATE WRITING CSS THEY TAKE TOO MUCH TIME
//AYE THIS BAR IS KINDA FINE
//BUT I GOTTA FINISH THIS BEFORE I RUN OUTTA TIME

function Home(){

    const [searchyQuery, setSearchQuery] = useState("")
    const [movies, setMovies] = useState([])
    const [error, setError] = useState(null)
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        const loadPopularMovies = async () => {

            try{
                const popularMovies = await getPopularMovies
                setMovies(popularMovies)
            }catch(err){
                setError("Failed to load.")
            }
            finally{
                setLoading(false)
            }
        }
    }, [])
    const searchMovie = (e) => {
        e.preventDefault() // I FUCKING HATe IT WHEN MY SEARCH GETS CLEARED
        alert(searchyQuery)


    }

    return <div className="home">

        
       
        <form onSubmit={searchMovie} className="search-form">

            <input type="text" 
            placeholder="Search..." 
            className="search-input" 
            value={searchyQuery} //input constantly updates 
            onChange={(e) => setSearchQuery(e.target.value)}
            />
                
            <button type="submit" className="search-button">Search</button>
            
           
            
        
        </form>
        <div className="movies-grid">
            {movies.map(movie =>( //displays the array of movies
                <Moviecard movie={movie} key={movie.uuid}/>
            ))}

            
        </div>




    </div>
}

export default Home