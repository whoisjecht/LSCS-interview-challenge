//Navigation Bar

import { Link } from "react-router-dom";
import "../css/Navbar.css";

function Nav(){
    return <nav className="navbar">
        <div className="navbar-brand">
            <Link to="/">MOVIE</Link>


        </div>
        <div className="navbar-links">
            <Link to="/" className="nav-link">HOME </Link>
            <Link to="/favourites" className="nav-link">FAVOURITES </Link>
            


        </div>


    </nav>
}

export default Nav