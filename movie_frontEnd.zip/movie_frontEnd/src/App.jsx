import "./CSS/App.css"

import Favourite from './Pages/FavouriteMovies';
import Home from './Pages/Home';
import Nav from './Components/Nav';
import { Routes, Route } from 'react-router-dom';
function App() {
  return (
      <div>
        <Nav />
      
      <main className='main'> 
        <Routes>
          <Route path='/' element={<Home />}/>
          <Route path='/favourites' element={<Favourite />}/> 



        </Routes>

        

      </main>
      </div>


  );
}

export default App
